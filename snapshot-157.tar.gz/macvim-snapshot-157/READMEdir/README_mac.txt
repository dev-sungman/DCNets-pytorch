README_mac.txt for version 8.1 of Vim: Vi IMproved.

How to install MacVim?
========================

Download MacVim.dmg from latest binary release page https://github.com/macvim-dev/macvim/releases/latest , open the dmg file, and copy MacVim.app to /Applications.


Questions?
========================

Please take a look at the home page http://macvim-dev.github.io/macvim/

