//
//  AppController.h
//  PSMTabBarControl
//
//  Created by John Pannell on 12/19/05.
//  Copyright 2005 Positive Spin Media. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppController : NSObject {
    
}

- (IBAction)newWindow:(id)sender;

@end
