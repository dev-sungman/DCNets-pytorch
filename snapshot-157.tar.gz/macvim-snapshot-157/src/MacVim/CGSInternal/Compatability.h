/*
 *  Compatability.h
 *  iTerm
 *
 *  Created by Marc on 10.08.10.
 *  Copyright 2010 Marc Haisenko. All rights reserved.
 *
 */

#pragma once

#include <Carbon/Carbon.h>

#ifndef CG_EXTERN_C_BEGIN
#define CG_EXTERN_C_BEGIN
#define CG_EXTERN_C_END
#endif

#ifndef CG_EXTERN
#define CG_EXTERN
#endif
